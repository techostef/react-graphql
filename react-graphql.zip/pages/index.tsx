import Home from '../features/home'
import MainLayout from '../features/shared/layouts/MainLayouts'

function HomePage() {
  return (
    <MainLayout>
      <Home />
    </MainLayout>
  )
}

export default HomePage
