import React, { FunctionComponent } from 'react';
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client';
import "core-js/stable";
import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import "@next/polyfill-module";
import "@next/polyfill-nomodule";

import '../styles/globals.css'

const client = new ApolloClient({
  uri: 'https://graphql.anilist.co',
  cache: new InMemoryCache(),
});

interface IProps {
  Component: FunctionComponent;
  pageProps: Record<string, any>;
}

function App ({ Component, pageProps }: IProps) {
  return (
    <ApolloProvider client={client}>
      <Component {...pageProps} />
    </ApolloProvider>
  )
}

export default App
