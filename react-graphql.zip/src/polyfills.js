import "core-js/stable";
import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import "@next/polyfill-module";
import "@next/polyfill-nomodule";