import { css } from '@emotion/css';
import { useAnimeList } from './hooks/useAnimeList';
import { AnimeList } from '../shared/components/AnimeList';
import { convertDataAnimeListToAnimeItems } from './utils';
import theme from '../shared/config/theme';
import Box from '../shared/components/Box';

function Home () {
  const { data } = useAnimeList();

  return (
    <div>
      <h1 className={styles.title}>
        Anime List
      </h1>
      <Box>
        <AnimeList data={convertDataAnimeListToAnimeItems(data?.Page)} />
      </Box>
    </div>
  )
}

const styles = {
  title: css({
    color: theme.color.grayLight
  })
}

export default Home;