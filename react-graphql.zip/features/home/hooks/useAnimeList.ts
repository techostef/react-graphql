import { useQuery, } from '@apollo/client';
import { QUERY_GET_ANIME_LIST } from '../query';

const variables = {
  page: 1,
  perPage: 10
};

export interface IDataAnimeList {
  Page: {
    __typename: string
    pageInfo: PageInfo
    media: Media[]
  }
}

interface PageInfo {
  __typename: string
  total: number
  perPage: number
  currentPage: number
  lastPage: number
  hasNextPage: boolean
}

interface Media {
  __typename: string
  id: number
  title: Title
  coverImage: CoverImage
  description: string
  seasonYear: number
  status: string;
  episodes: number;
}

interface Title {
  __typename: string
  romaji: string
}

interface CoverImage {
  __typename: string
  medium: string
}


export function useAnimeList () {
  const { loading, error, data } = useQuery<IDataAnimeList>(QUERY_GET_ANIME_LIST,  {
    variables
  });

  return {
    loading, 
    error,
    data
  }
}