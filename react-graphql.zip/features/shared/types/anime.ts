export interface IAnimeItem {
  id: number;
  title: string;
  coverImage: string;
  seasonYear: number;
  status: string;
  episodes: number;
}