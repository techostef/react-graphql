import React from 'react';
import { css } from '@emotion/css';
import theme from '../config/theme';


interface IProps {
  children: React.ReactNode
}

function MainLayout ({ children }: IProps) {
  return (
    <div className={styles.container}>
      <div className={styles.content}>
        {children}
      </div>
    </div>
  )
}

const styles = {
  container: css({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '100%',
    height: '100vh',
    backgroundColor: theme.color.dark
  }),
  content: css({
    width: 800
  })
}

export default MainLayout;