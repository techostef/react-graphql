import { css } from "@emotion/css";
import { IAnimeItem } from "../../../types/anime";
import theme from "../../../config/theme";

interface IProps extends IAnimeItem {}

function AnimeItem({ title, coverImage, seasonYear, status, episodes }: IProps) {
  return (
    <div className={styles.container}>
      <img
        className={styles.image}
        src={coverImage}
        alt="Picture of the author"
      />
      <div className={styles.content}>
        <div className={styles.title}>{title}</div>
        <div className={styles.text}>Year: {seasonYear}</div>
        <div className={styles.text}>Status: {status}</div>
        <div className={styles.text}>Episode: {episodes}</div>
      </div>
    </div>
  );
}

const styles = {
  container: css({
    width: 385,
    display: "flex",
  }),
  image: css({
    width: 150,
    minWidth: 150,
    minHeight: 120,
    height: 120,
  }),
  title: css({
    fontSize: 18,
    color: theme.color.grayLight,
    marginBottom: theme.spacing.m,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  }),
  text: css({
    color: theme.color.gray,
    marginBottom: theme.spacing.xxs,
  }),
  content: css({
    display: "flex",
    flexDirection: "column",
    marginLeft: theme.spacing.s,
    overflowX: "hidden",
  }),
};

export default AnimeItem;
