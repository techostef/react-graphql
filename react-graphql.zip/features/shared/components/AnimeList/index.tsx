import AnimeList from "./List"

export {
  AnimeList
}