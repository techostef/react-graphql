import { css } from '@emotion/css';
import { IAnimeItem } from "../../types/anime"
import AnimeItem from "./AnimeItem"

interface IProps {
  data?: IAnimeItem[]
}

function AnimeList ({ data }: IProps) {
  if (!data) {
    return null;
  }
  return (
    <div className={styles.container}>
      {data.map((anime) => <AnimeItem key={anime.id} {...anime} />)}
    </div>
  )
}

const styles = {
  container: css({
    display: 'flex',
    flexWrap: 'wrap',
    rowGap: 22
  })
}

export default AnimeList;