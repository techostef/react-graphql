const color = {
  gray: '#d1d1d1',
  grayLight: '#ededed',
  dark: '#212121',
  darkLight: '#292929',
}

const spacing = {
  xxs: 4,
  xs: 8,
  s: 12,
  m: 16,
  l: 24,
  xl: 30
}

const theme = {
  color,
  spacing
}

export default theme